import click
from vpolo.alevin import parser

@click.command()
@click.option('--one',  help='path to first alevin')
@click.option('--two',  help='path to second alevin')
def match(one, two):
	orig = parser.read_quants_bin(one)
	new = parser.read_quants_bin(two)
	diff = orig - new
	if diff.sum().sum() > 0:
		print("Test failed with diff: {}".format(diff.sum().sum()))
	else:
		print("Test Passed")

if __name__=="__main__":
    match()
