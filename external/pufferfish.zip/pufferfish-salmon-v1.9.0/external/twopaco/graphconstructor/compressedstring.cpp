#include "compressedstring.h"

namespace TwoPaCo
{
	extern const size_t UNIT_CAPACITY = 32;
}