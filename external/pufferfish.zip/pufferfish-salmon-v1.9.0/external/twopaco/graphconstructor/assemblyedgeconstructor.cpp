#include "assemblyedgeconstructor.h"

namespace TwoPaCo
{
	
}