#include "common.h"

namespace TwoPaCo
{
	const int64_t INVALID_VERTEX = INT64_MAX;
	const uint32_t MAX_COUNTER = UINT32_MAX >> 1;
}