#!/bin/bash
source /hbb_exe/activate

set -e

# ci testing add unit tests here
